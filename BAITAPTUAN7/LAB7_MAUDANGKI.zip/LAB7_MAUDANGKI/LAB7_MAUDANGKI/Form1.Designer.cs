﻿namespace LAB7_MAUDANGKI
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblTitle = new Label();
            lblHoTen = new Label();
            txtHoTen = new TextBox();
            lblTenDangNhap = new Label();
            txtTenDangNhap = new TextBox();
            lblEmail = new Label();
            txtEmail = new TextBox();
            lblSoDienThoai = new Label();
            txtSoDienThoai = new TextBox();
            lblMatKhau = new Label();
            txtMatKhau = new TextBox();
            lblXacNhanMatKhau = new Label();
            txtXacNhanMatKhau = new TextBox();
            lblNgaySinh = new Label();
            dtpNgaySinh = new DateTimePicker();
            lblGioiTinh = new Label();
            rbNam = new RadioButton();
            rbNu = new RadioButton();
            rbKhongMuonTietLo = new RadioButton();
            lblMaGioiThieu = new Label();
            txtMaGioiThieu = new TextBox();
            chkDongYDieuKhoan = new CheckBox();
            btnDangKy = new Button();
            btnDangNhap = new Button();
            SuspendLayout();
            // 
            // lblTitle
            // 
            lblTitle.BackColor = Color.SteelBlue;
            lblTitle.Font = new Font("Microsoft Sans Serif", 14F, FontStyle.Bold);
            lblTitle.ForeColor = Color.White;
            lblTitle.Location = new Point(0, 0);
            lblTitle.Margin = new Padding(5, 0, 5, 0);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(1000, 77);
            lblTitle.TabIndex = 0;
            lblTitle.Text = "Form Đăng Ký Tài Khoản - ShopVN.vn";
            lblTitle.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblHoTen
            // 
            lblHoTen.AutoSize = true;
            lblHoTen.Font = new Font("Microsoft Sans Serif", 9F);
            lblHoTen.Location = new Point(33, 115);
            lblHoTen.Margin = new Padding(5, 0, 5, 0);
            lblHoTen.Name = "lblHoTen";
            lblHoTen.Size = new Size(111, 22);
            lblHoTen.TabIndex = 1;
            lblHoTen.Text = "Họ và tên (*)";
            // 
            // txtHoTen
            // 
            txtHoTen.Location = new Point(250, 112);
            txtHoTen.Margin = new Padding(5, 6, 5, 6);
            txtHoTen.MaxLength = 50;
            txtHoTen.Name = "txtHoTen";
            txtHoTen.Size = new Size(664, 31);
            txtHoTen.TabIndex = 2;
            txtHoTen.TextChanged += txtHoTen_TextChanged;
            // 
            // lblTenDangNhap
            // 
            lblTenDangNhap.AutoSize = true;
            lblTenDangNhap.Font = new Font("Microsoft Sans Serif", 9F);
            lblTenDangNhap.Location = new Point(33, 173);
            lblTenDangNhap.Margin = new Padding(5, 0, 5, 0);
            lblTenDangNhap.Name = "lblTenDangNhap";
            lblTenDangNhap.Size = new Size(156, 22);
            lblTenDangNhap.TabIndex = 3;
            lblTenDangNhap.Text = "Tên đăng nhập (*)";
            // 
            // txtTenDangNhap
            // 
            txtTenDangNhap.Location = new Point(250, 169);
            txtTenDangNhap.Margin = new Padding(5, 6, 5, 6);
            txtTenDangNhap.MaxLength = 20;
            txtTenDangNhap.Name = "txtTenDangNhap";
            txtTenDangNhap.Size = new Size(664, 31);
            txtTenDangNhap.TabIndex = 4;
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.Font = new Font("Microsoft Sans Serif", 9F);
            lblEmail.Location = new Point(33, 231);
            lblEmail.Margin = new Padding(5, 0, 5, 0);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(78, 22);
            lblEmail.TabIndex = 5;
            lblEmail.Text = "Email (*)";
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(250, 227);
            txtEmail.Margin = new Padding(5, 6, 5, 6);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(664, 31);
            txtEmail.TabIndex = 6;
            // 
            // lblSoDienThoai
            // 
            lblSoDienThoai.AutoSize = true;
            lblSoDienThoai.Font = new Font("Microsoft Sans Serif", 9F);
            lblSoDienThoai.Location = new Point(33, 288);
            lblSoDienThoai.Margin = new Padding(5, 0, 5, 0);
            lblSoDienThoai.Name = "lblSoDienThoai";
            lblSoDienThoai.Size = new Size(139, 22);
            lblSoDienThoai.TabIndex = 7;
            lblSoDienThoai.Text = "Số điện thoại (*)";
            // 
            // txtSoDienThoai
            // 
            txtSoDienThoai.Location = new Point(250, 285);
            txtSoDienThoai.Margin = new Padding(5, 6, 5, 6);
            txtSoDienThoai.MaxLength = 10;
            txtSoDienThoai.Name = "txtSoDienThoai";
            txtSoDienThoai.Size = new Size(664, 31);
            txtSoDienThoai.TabIndex = 8;
            // 
            // lblMatKhau
            // 
            lblMatKhau.AutoSize = true;
            lblMatKhau.Font = new Font("Microsoft Sans Serif", 9F);
            lblMatKhau.Location = new Point(33, 346);
            lblMatKhau.Margin = new Padding(5, 0, 5, 0);
            lblMatKhau.Name = "lblMatKhau";
            lblMatKhau.Size = new Size(107, 22);
            lblMatKhau.TabIndex = 9;
            lblMatKhau.Text = "Mật khẩu (*)";
            // 
            // txtMatKhau
            // 
            txtMatKhau.Location = new Point(250, 342);
            txtMatKhau.Margin = new Padding(5, 6, 5, 6);
            txtMatKhau.MaxLength = 32;
            txtMatKhau.Name = "txtMatKhau";
            txtMatKhau.PasswordChar = '*';
            txtMatKhau.Size = new Size(664, 31);
            txtMatKhau.TabIndex = 10;
            // 
            // lblXacNhanMatKhau
            // 
            lblXacNhanMatKhau.AutoSize = true;
            lblXacNhanMatKhau.Font = new Font("Microsoft Sans Serif", 9F);
            lblXacNhanMatKhau.Location = new Point(33, 404);
            lblXacNhanMatKhau.Margin = new Padding(5, 0, 5, 0);
            lblXacNhanMatKhau.Name = "lblXacNhanMatKhau";
            lblXacNhanMatKhau.Size = new Size(188, 22);
            lblXacNhanMatKhau.TabIndex = 11;
            lblXacNhanMatKhau.Text = "Xác nhận mật khẩu (*)";
            // 
            // txtXacNhanMatKhau
            // 
            txtXacNhanMatKhau.Location = new Point(250, 400);
            txtXacNhanMatKhau.Margin = new Padding(5, 6, 5, 6);
            txtXacNhanMatKhau.MaxLength = 32;
            txtXacNhanMatKhau.Name = "txtXacNhanMatKhau";
            txtXacNhanMatKhau.PasswordChar = '*';
            txtXacNhanMatKhau.Size = new Size(664, 31);
            txtXacNhanMatKhau.TabIndex = 12;
            // 
            // lblNgaySinh
            // 
            lblNgaySinh.AutoSize = true;
            lblNgaySinh.Font = new Font("Microsoft Sans Serif", 9F);
            lblNgaySinh.Location = new Point(33, 462);
            lblNgaySinh.Margin = new Padding(5, 0, 5, 0);
            lblNgaySinh.Name = "lblNgaySinh";
            lblNgaySinh.Size = new Size(90, 22);
            lblNgaySinh.TabIndex = 13;
            lblNgaySinh.Text = "Ngày sinh";
            // 
            // dtpNgaySinh
            // 
            dtpNgaySinh.Format = DateTimePickerFormat.Short;
            dtpNgaySinh.Location = new Point(250, 458);
            dtpNgaySinh.Margin = new Padding(5, 6, 5, 6);
            dtpNgaySinh.MaxDate = new DateTime(2010, 3, 3, 0, 0, 0, 0);
            dtpNgaySinh.MinDate = new DateTime(1924, 1, 1, 0, 0, 0, 0);
            dtpNgaySinh.Name = "dtpNgaySinh";
            dtpNgaySinh.Size = new Size(331, 31);
            dtpNgaySinh.TabIndex = 14;
            dtpNgaySinh.Value = new DateTime(2000, 1, 1, 0, 0, 0, 0);
            // 
            // lblGioiTinh
            // 
            lblGioiTinh.AutoSize = true;
            lblGioiTinh.Font = new Font("Microsoft Sans Serif", 9F);
            lblGioiTinh.Location = new Point(33, 519);
            lblGioiTinh.Margin = new Padding(5, 0, 5, 0);
            lblGioiTinh.Name = "lblGioiTinh";
            lblGioiTinh.Size = new Size(76, 22);
            lblGioiTinh.TabIndex = 15;
            lblGioiTinh.Text = "Giới tính";
            // 
            // rbNam
            // 
            rbNam.AutoSize = true;
            rbNam.Checked = true;
            rbNam.Location = new Point(250, 519);
            rbNam.Margin = new Padding(5, 6, 5, 6);
            rbNam.Name = "rbNam";
            rbNam.Size = new Size(75, 29);
            rbNam.TabIndex = 16;
            rbNam.TabStop = true;
            rbNam.Text = "Nam";
            rbNam.UseVisualStyleBackColor = true;
            // 
            // rbNu
            // 
            rbNu.AutoSize = true;
            rbNu.Location = new Point(367, 519);
            rbNu.Margin = new Padding(5, 6, 5, 6);
            rbNu.Name = "rbNu";
            rbNu.Size = new Size(61, 29);
            rbNu.TabIndex = 17;
            rbNu.Text = "Nữ";
            rbNu.UseVisualStyleBackColor = true;
            // 
            // rbKhongMuonTietLo
            // 
            rbKhongMuonTietLo.AutoSize = true;
            rbKhongMuonTietLo.Location = new Point(467, 519);
            rbKhongMuonTietLo.Margin = new Padding(5, 6, 5, 6);
            rbKhongMuonTietLo.Name = "rbKhongMuonTietLo";
            rbKhongMuonTietLo.Size = new Size(191, 29);
            rbKhongMuonTietLo.TabIndex = 18;
            rbKhongMuonTietLo.Text = "Không muốn tiết lộ";
            rbKhongMuonTietLo.UseVisualStyleBackColor = true;
            // 
            // lblMaGioiThieu
            // 
            lblMaGioiThieu.AutoSize = true;
            lblMaGioiThieu.Font = new Font("Microsoft Sans Serif", 9F);
            lblMaGioiThieu.Location = new Point(33, 577);
            lblMaGioiThieu.Margin = new Padding(5, 0, 5, 0);
            lblMaGioiThieu.Name = "lblMaGioiThieu";
            lblMaGioiThieu.Size = new Size(111, 22);
            lblMaGioiThieu.TabIndex = 19;
            lblMaGioiThieu.Text = "Mã giới thiệu";
            // 
            // txtMaGioiThieu
            // 
            txtMaGioiThieu.Location = new Point(250, 573);
            txtMaGioiThieu.Margin = new Padding(5, 6, 5, 6);
            txtMaGioiThieu.MaxLength = 8;
            txtMaGioiThieu.Name = "txtMaGioiThieu";
            txtMaGioiThieu.Size = new Size(331, 31);
            txtMaGioiThieu.TabIndex = 20;
            // 
            // chkDongYDieuKhoan
            // 
            chkDongYDieuKhoan.AutoSize = true;
            chkDongYDieuKhoan.Font = new Font("Microsoft Sans Serif", 9F);
            chkDongYDieuKhoan.Location = new Point(33, 635);
            chkDongYDieuKhoan.Margin = new Padding(5, 6, 5, 6);
            chkDongYDieuKhoan.Name = "chkDongYDieuKhoan";
            chkDongYDieuKhoan.Size = new Size(702, 26);
            chkDongYDieuKhoan.TabIndex = 21;
            chkDongYDieuKhoan.Text = "Đồng ý Điều khoản (*) - Checkbox phải được tích. Link 'Xem Điều khoản' mở popup.";
            chkDongYDieuKhoan.UseVisualStyleBackColor = true;
            // 
            // btnDangKy
            // 
            btnDangKy.BackColor = Color.SteelBlue;
            btnDangKy.Font = new Font("Microsoft Sans Serif", 10F, FontStyle.Bold);
            btnDangKy.ForeColor = Color.White;
            btnDangKy.Location = new Point(250, 692);
            btnDangKy.Margin = new Padding(5, 6, 5, 6);
            btnDangKy.Name = "btnDangKy";
            btnDangKy.Size = new Size(167, 67);
            btnDangKy.TabIndex = 22;
            btnDangKy.Text = "Đăng ký";
            btnDangKy.UseVisualStyleBackColor = false;
            btnDangKy.Click += btnDangKy_Click;
            // 
            // btnDangNhap
            // 
            btnDangNhap.BackColor = Color.Gray;
            btnDangNhap.Font = new Font("Microsoft Sans Serif", 10F);
            btnDangNhap.ForeColor = Color.White;
            btnDangNhap.Location = new Point(450, 692);
            btnDangNhap.Margin = new Padding(5, 6, 5, 6);
            btnDangNhap.Name = "btnDangNhap";
            btnDangNhap.Size = new Size(167, 67);
            btnDangNhap.TabIndex = 23;
            btnDangNhap.Text = "Đăng nhập";
            btnDangNhap.UseVisualStyleBackColor = false;
            btnDangNhap.Click += btnDangNhap_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1000, 808);
            Controls.Add(btnDangNhap);
            Controls.Add(btnDangKy);
            Controls.Add(chkDongYDieuKhoan);
            Controls.Add(txtMaGioiThieu);
            Controls.Add(lblMaGioiThieu);
            Controls.Add(rbKhongMuonTietLo);
            Controls.Add(rbNu);
            Controls.Add(rbNam);
            Controls.Add(lblGioiTinh);
            Controls.Add(dtpNgaySinh);
            Controls.Add(lblNgaySinh);
            Controls.Add(txtXacNhanMatKhau);
            Controls.Add(lblXacNhanMatKhau);
            Controls.Add(txtMatKhau);
            Controls.Add(lblMatKhau);
            Controls.Add(txtSoDienThoai);
            Controls.Add(lblSoDienThoai);
            Controls.Add(txtEmail);
            Controls.Add(lblEmail);
            Controls.Add(txtTenDangNhap);
            Controls.Add(lblTenDangNhap);
            Controls.Add(txtHoTen);
            Controls.Add(lblHoTen);
            Controls.Add(lblTitle);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Margin = new Padding(5, 6, 5, 6);
            MaximizeBox = false;
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form Đăng Ký Tài Khoản - ShopVN.vn";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblHoTen;
        private System.Windows.Forms.TextBox txtHoTen;
        private System.Windows.Forms.Label lblTenDangNhap;
        private System.Windows.Forms.TextBox txtTenDangNhap;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label lblSoDienThoai;
        private System.Windows.Forms.TextBox txtSoDienThoai;
        private System.Windows.Forms.Label lblMatKhau;
        private System.Windows.Forms.TextBox txtMatKhau;
        private System.Windows.Forms.Label lblXacNhanMatKhau;
        private System.Windows.Forms.TextBox txtXacNhanMatKhau;
        private System.Windows.Forms.Label lblNgaySinh;
        private System.Windows.Forms.DateTimePicker dtpNgaySinh;
        private System.Windows.Forms.Label lblGioiTinh;
        private System.Windows.Forms.RadioButton rbNam;
        private System.Windows.Forms.RadioButton rbNu;
        private System.Windows.Forms.RadioButton rbKhongMuonTietLo;
        private System.Windows.Forms.Label lblMaGioiThieu;
        private System.Windows.Forms.TextBox txtMaGioiThieu;
        private System.Windows.Forms.CheckBox chkDongYDieuKhoan;
        private System.Windows.Forms.Button btnDangKy;
        private System.Windows.Forms.Button btnDangNhap;
    }
}