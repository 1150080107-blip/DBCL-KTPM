using System.Text.RegularExpressions;

namespace LAB7_MAUDANGKI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnDangKy_Click(object sender, EventArgs e)
        {
            if (ValidateForm())
            {
                MessageBox.Show("Đăng ký thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                // Gửi form hoặc disable nếu còn trường bắt buộc trống (client-side validation)
            }
        }

        private void btnDangNhap_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Chuyển sang trang đăng nhập", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            // Link chuyển sang trang đăng nhập
        }

        private bool ValidateForm()
        {
            // Kiểm tra họ tên (bắt buộc, 2-50 ký tự)
            if (string.IsNullOrWhiteSpace(txtHoTen.Text) || txtHoTen.Text.Length < 2 || txtHoTen.Text.Length > 50)
            {
                MessageBox.Show("Họ và tên là bắt buộc. Chỉ chứa chữ cái (có dấu hoặc không dấu) và dấu cách. Độ dài 2-50 ký tự.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtHoTen.Focus();
                return false;
            }

            // Kiểm tra tên đăng nhập (bắt buộc, chữ thường, số, dấu gạch dưới, 5-20 ký tự, phải là duy nhất)
            if (string.IsNullOrWhiteSpace(txtTenDangNhap.Text) || txtTenDangNhap.Text.Length < 5 || txtTenDangNhap.Text.Length > 20)
            {
                MessageBox.Show("Tên đăng nhập là bắt buộc. Chỉ chứa chữ thường, số, dấu gạch dưới. Bắt đầu bằng chữ cái. Dài 5-20 ký tự. Phải là duy nhất.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtTenDangNhap.Focus();
                return false;
            }

            if (!Regex.IsMatch(txtTenDangNhap.Text, @"^[a-z][a-z0-9_]*$"))
            {
                MessageBox.Show("Tên đăng nhập chỉ được chứa chữ thường, số, dấu gạch dưới và phải bắt đầu bằng chữ cái.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtTenDangNhap.Focus();
                return false;
            }

            // Kiểm tra email (bắt buộc, định dạng email chuẩn RFC 5322)
            if (string.IsNullOrWhiteSpace(txtEmail.Text) || !IsValidEmail(txtEmail.Text))
            {
                MessageBox.Show("Email là bắt buộc. Đúng định dạng email chuẩn RFC 5322. Chưa được đăng ký trong hệ thống.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtEmail.Focus();
                return false;
            }

            // Kiểm tra số điện thoại (bắt buộc, số Việt Nam: bắt đầu bằng 0, gồm 10 chữ số liên tiếp)
            if (string.IsNullOrWhiteSpace(txtSoDienThoai.Text) || !Regex.IsMatch(txtSoDienThoai.Text, @"^0\d{9}$"))
            {
                MessageBox.Show("Số điện thoại là bắt buộc. Số Việt Nam: bắt đầu bằng 0, gồm 10 chữ số liên tiếp. VD: 0987654321.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtSoDienThoai.Focus();
                return false;
            }

            // Kiểm tra mật khẩu (bắt buộc, 8-32 ký tự, phải có ít nhất: 1 chữ hoa, 1 chữ thường, 1 chữ số, 1 ký tự đặc biệt)
            if (string.IsNullOrWhiteSpace(txtMatKhau.Text) || txtMatKhau.Text.Length < 8 || txtMatKhau.Text.Length > 32)
            {
                MessageBox.Show("Mật khẩu là bắt buộc. 8-32 ký tự. Phải có ít nhất: 1 chữ hoa, 1 chữ thường, 1 chữ số, 1 ký tự đặc biệt (!@#$%...).", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtMatKhau.Focus();
                return false;
            }

            if (!Regex.IsMatch(txtMatKhau.Text, @"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+\-=\[\]{};':""\\|,.<>\/?]).{8,32}$"))
            {
                MessageBox.Show("Mật khẩu phải có ít nhất: 1 chữ hoa, 1 chữ thường, 1 chữ số, 1 ký tự đặc biệt.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtMatKhau.Focus();
                return false;
            }

            // Kiểm tra xác nhận mật khẩu (bắt buộc, phải trùng khớp hoàn toàn với trường Mật khẩu)
            if (txtXacNhanMatKhau.Text != txtMatKhau.Text)
            {
                MessageBox.Show("Xác nhận mật khẩu là bắt buộc. Phải trùng khớp hoàn toàn với trường Mật khẩu.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtXacNhanMatKhau.Focus();
                return false;
            }

            // Kiểm tra ngày sinh (không bắt buộc, định dạng dd/mm/yyyy, phải từ 16 tuổi đến dưới 100 tuổi tính đến ngày đăng ký)
            DateTime today = DateTime.Today;
            int age = today.Year - dtpNgaySinh.Value.Year;
            if (dtpNgaySinh.Value.Date > today.AddYears(-age)) age--;

            if (age < 16 || age >= 100)
            {
                MessageBox.Show("Ngày sinh không bắt buộc. Định dạng dd/mm/yyyy. Phải từ 16 tuổi đến dưới 100 tuổi tính đến ngày đăng ký.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                dtpNgaySinh.Focus();
                return false;
            }

            // Kiểm tra mã giới thiệu (không bắt buộc, 8 ký tự chữ hoa và số, hệ thống kiểm tra mã có tồn tại trong CSDL)
            if (!string.IsNullOrWhiteSpace(txtMaGioiThieu.Text))
            {
                if (txtMaGioiThieu.Text.Length != 8 || !Regex.IsMatch(txtMaGioiThieu.Text, @"^[A-Z0-9]{8}$"))
                {
                    MessageBox.Show("Mã giới thiệu không bắt buộc. 8 ký tự chữ hoa và số. Hệ thống kiểm tra mã có tồn tại trong CSDL.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtMaGioiThieu.Focus();
                    return false;
                }
            }

            // Kiểm tra đồng ý điều khoản (bắt buộc, checkbox phải được tích)
            if (!chkDongYDieuKhoan.Checked)
            {
                MessageBox.Show("Đồng ý Điều khoản là bắt buộc. Checkbox phải được tích. Link 'Xem Điều khoản' mở popup.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                chkDongYDieuKhoan.Focus();
                return false;
            }

            return true;
        }

        private bool IsValidEmail(string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }

        private void txtHoTen_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
