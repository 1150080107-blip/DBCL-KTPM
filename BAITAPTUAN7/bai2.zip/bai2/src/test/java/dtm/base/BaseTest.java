package dtm.base;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import java.io.File;
import java.lang.reflect.Method;
import java.time.Duration;

public abstract class BaseTest {
    // ThreadLocal để hỗ trợ parallel execution
    private static ThreadLocal<WebDriver> driver = new ThreadLocal<>();

    @BeforeMethod
    public void setUp(Method method) {
        // Khởi tạo ChromeDriver qua WebDriverManager
        WebDriverManager.chromedriver().setup();
        WebDriver webDriver = new ChromeDriver();
        
        // Maximize window, set implicit wait 10s
        webDriver.manage().window().maximize();
        webDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        
        // Gán driver vào ThreadLocal
        driver.set(webDriver);
        
        // Ghi log tên test đang chạy
        System.out.println("Starting test: " + method.getName());
    }

    @AfterMethod
    public void tearDown(ITestResult result) {
        // Nếu result là FAILURE → chụp screenshot
        if (result.getStatus() == ITestResult.FAILURE) {
            takeScreenshot(result.getName());
        }
        
        // Đóng driver
        WebDriver webDriver = getDriver();
        if (webDriver != null) {
            webDriver.quit();
        }
        
        // Remove ThreadLocal
        driver.remove();
    }

    public WebDriver getDriver() {
        return driver.get();
    }

    private void takeScreenshot(String testName) {
        try {
            WebDriver webDriver = getDriver();
            TakesScreenshot screenshot = (TakesScreenshot) webDriver;
            File srcFile = screenshot.getScreenshotAs(OutputType.FILE);
            
            // Tạo thư mục screenshots nếu chưa có
            File destDir = new File("screenshots");
            if (!destDir.exists()) {
                destDir.mkdirs();
            }
            
            File destFile = new File("screenshots/" + testName + "_" + System.currentTimeMillis() + ".png");
            FileUtils.copyFile(srcFile, destFile);
            System.out.println("Screenshot saved: " + destFile.getAbsolutePath());
        } catch (Exception e) {
            System.out.println("Failed to take screenshot: " + e.getMessage());
        }
    }
}
