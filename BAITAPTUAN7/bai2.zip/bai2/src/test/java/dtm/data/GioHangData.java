package dtm.data;

import org.testng.annotations.DataProvider;

public class GioHangData {

    @DataProvider(name = "cartData")
    public Object[][] getCartData() {
        return new Object[][] {
            {"Sauce Labs Backpack", 1},
            {"Sauce Labs Bike Light", 2},
            {"Sauce Labs Bolt T-Shirt", 3},
            {"Sauce Labs Fleece Jacket", 1}
        };
    }

    @DataProvider(name = "removeCartData")
    public Object[][] getRemoveCartData() {
        return new Object[][] {
            {"Sauce Labs Backpack"},
            {"Sauce Labs Bike Light"},
            {"Sauce Labs Onesie"}
        };
    }
}
