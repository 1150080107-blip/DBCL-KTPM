package dtm.data;

import org.testng.annotations.DataProvider;

public class DangNhapData {

    @DataProvider(name = "loginData")
    public Object[][] getLoginData() {
        return new Object[][] {
            {"standard_user", "secret_sauce", true},
            {"locked_out_user", "secret_sauce", false},
            {"problem_user", "secret_sauce", true},
            {"performance_glitch_user", "secret_sauce", true},
            {"invalid_user", "wrong_password", false}
        };
    }

    @DataProvider(name = "invalidLoginData")
    public Object[][] getInvalidLoginData() {
        return new Object[][] {
            {"", "", "Username is required"},
            {"standard_user", "", "Password is required"},
            {"", "secret_sauce", "Username is required"},
            {"invalid_user", "invalid_pass", "Username and password do not match"}
        };
    }
}
