package dtm.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class InventoryPage {
    private WebDriver driver;
    private WebDriverWait wait;

    // Locators
    private By inventoryItems = By.className("inventory_item");
    private By shoppingCartBadge = By.className("shopping_cart_badge");
    private By shoppingCartLink = By.className("shopping_cart_link");

    public InventoryPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public void addItemToCart(String itemName) {
        String buttonId = "add-to-cart-" + itemName.toLowerCase().replace(" ", "-");
        WebElement addButton = driver.findElement(By.id(buttonId));
        addButton.click();
    }

    public int getCartItemCount() {
        try {
            String count = driver.findElement(shoppingCartBadge).getText();
            return Integer.parseInt(count);
        } catch (Exception e) {
            return 0;
        }
    }

    public void goToCart() {
        driver.findElement(shoppingCartLink).click();
    }

    public boolean isItemDisplayed(String itemName) {
        List<WebElement> items = driver.findElements(inventoryItems);
        return items.stream().anyMatch(item -> item.getText().contains(itemName));
    }
}
