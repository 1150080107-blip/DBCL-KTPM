package dtm.tests;

import dtm.base.BaseTest;
import dtm.pages.InventoryPage;
import dtm.pages.LoginPage;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class TC_TimKiemTest extends BaseTest {

    @BeforeMethod
    public void loginBeforeTest() {
        LoginPage loginPage = new LoginPage(getDriver());
        loginPage.navigateToLoginPage("https://www.saucedemo.com/");
        loginPage.login("standard_user", "secret_sauce");
    }

    @DataProvider(name = "searchData")
    public Object[][] getSearchData() {
        return new Object[][] {
            {"Sauce Labs Backpack", true},
            {"Sauce Labs Bike Light", true},
            {"Sauce Labs Bolt T-Shirt", true},
            {"Non-existent Item", false}
        };
    }

    @Test(dataProvider = "searchData")
    public void testSearchItem(String itemName, boolean shouldExist) {
        InventoryPage inventoryPage = new InventoryPage(getDriver());
        
        boolean isDisplayed = inventoryPage.isItemDisplayed(itemName);
        
        if (shouldExist) {
            Assert.assertTrue(isDisplayed, "Item should be found: " + itemName);
        } else {
            Assert.assertFalse(isDisplayed, "Item should not be found: " + itemName);
        }
    }
}
