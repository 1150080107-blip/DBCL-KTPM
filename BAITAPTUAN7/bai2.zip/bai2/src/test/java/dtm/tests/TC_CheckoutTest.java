package dtm.tests;

import dtm.base.BaseTest;
import dtm.pages.CartPage;
import dtm.pages.CheckoutPage;
import dtm.pages.InventoryPage;
import dtm.pages.LoginPage;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class TC_CheckoutTest extends BaseTest {

    @BeforeMethod
    public void setupCheckout() {
        LoginPage loginPage = new LoginPage(getDriver());
        loginPage.navigateToLoginPage("https://www.saucedemo.com/");
        loginPage.login("standard_user", "secret_sauce");

        InventoryPage inventoryPage = new InventoryPage(getDriver());
        inventoryPage.addItemToCart("sauce-labs-backpack");
        inventoryPage.goToCart();

        CartPage cartPage = new CartPage(getDriver());
        cartPage.proceedToCheckout();
    }

    @DataProvider(name = "checkoutData")
    public Object[][] getCheckoutData() {
        return new Object[][] {
            {"John", "Doe", "12345", true},
            {"Jane", "Smith", "67890", true},
            {"", "Doe", "12345", false},
            {"John", "", "12345", false},
            {"John", "Doe", "", false}
        };
    }

    @Test(dataProvider = "checkoutData")
    public void testCheckout(String firstName, String lastName, String postalCode, boolean shouldSucceed) {
        CheckoutPage checkoutPage = new CheckoutPage(getDriver());
        
        checkoutPage.fillCheckoutInfo(firstName, lastName, postalCode);

        if (shouldSucceed) {
            checkoutPage.clickFinish();
            Assert.assertTrue(checkoutPage.isOrderComplete(), 
                "Order should be completed successfully");
        } else {
            String errorMsg = checkoutPage.getErrorMessage();
            Assert.assertFalse(errorMsg.isEmpty(), 
                "Error message should be displayed for invalid data");
        }
    }
}
