package dtm.tests;

import dtm.base.BaseTest;
import dtm.data.GioHangData;
import dtm.pages.CartPage;
import dtm.pages.InventoryPage;
import dtm.pages.LoginPage;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class TC_GioHangTest extends BaseTest {

    @BeforeMethod
    public void loginBeforeTest() {
        LoginPage loginPage = new LoginPage(getDriver());
        loginPage.navigateToLoginPage("https://www.saucedemo.com/");
        loginPage.login("standard_user", "secret_sauce");
    }

    @Test(dataProvider = "cartData", dataProviderClass = GioHangData.class)
    public void testAddToCart(String itemName, int expectedCount) {
        InventoryPage inventoryPage = new InventoryPage(getDriver());
        
        for (int i = 0; i < expectedCount; i++) {
            inventoryPage.addItemToCart(itemName);
        }

        int actualCount = inventoryPage.getCartItemCount();
        Assert.assertEquals(actualCount, expectedCount, 
            "Cart should contain " + expectedCount + " items");
    }

    @Test(dataProvider = "removeCartData", dataProviderClass = GioHangData.class)
    public void testRemoveFromCart(String itemName) {
        InventoryPage inventoryPage = new InventoryPage(getDriver());
        CartPage cartPage = new CartPage(getDriver());

        inventoryPage.addItemToCart(itemName);
        inventoryPage.goToCart();

        int initialCount = cartPage.getCartItemCount();
        cartPage.removeItem(itemName);
        int finalCount = cartPage.getCartItemCount();

        Assert.assertEquals(finalCount, initialCount - 1, 
            "Item should be removed from cart");
    }
}
