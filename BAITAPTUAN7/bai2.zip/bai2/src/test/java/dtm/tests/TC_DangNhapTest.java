package dtm.tests;

import dtm.base.BaseTest;
import dtm.data.DangNhapData;
import dtm.pages.LoginPage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TC_DangNhapTest extends BaseTest {

    @Test(dataProvider = "loginData", dataProviderClass = DangNhapData.class)
    public void testLoginWithDataProvider(String username, String password, boolean expectedSuccess) {
        LoginPage loginPage = new LoginPage(getDriver());
        
        loginPage.navigateToLoginPage("https://www.saucedemo.com/");
        loginPage.login(username, password);

        if (expectedSuccess) {
            Assert.assertTrue(loginPage.isLoginSuccessful(), 
                "Login should be successful for user: " + username);
        } else {
            Assert.assertFalse(loginPage.isLoginSuccessful(), 
                "Login should fail for user: " + username);
        }
    }

    @Test(dataProvider = "invalidLoginData", dataProviderClass = DangNhapData.class)
    public void testInvalidLogin(String username, String password, String expectedError) {
        LoginPage loginPage = new LoginPage(getDriver());
        
        loginPage.navigateToLoginPage("https://www.saucedemo.com/");
        loginPage.login(username, password);

        String actualError = loginPage.getErrorMessage();
        Assert.assertTrue(actualError.contains(expectedError) || !actualError.isEmpty(), 
            "Error message should be displayed");
    }
}
