public class AirthematicTest {
    
    // ✅ Test bắt ngoại lệ chia cho 0
    public void divide_ByZero_ShouldThrowException() {
        JunitMessage jm = new JunitMessage();
        try {
            jm.divide(10, 0);
            // Nếu không có exception thì test fail
            throw new AssertionError("Expected ArithmeticException");
        } catch (ArithmeticException e) {
            // Test pass - đúng như mong đợi
            System.out.println("✅ Test chia cho 0: PASS");
        }
    }
    
    // (khuyến nghị) ✅ Test chia bình thường để bài đầy đủ hơn
    public void divide_Normal_ShouldReturnCorrectValue() {
        JunitMessage jm = new JunitMessage();
        int result = jm.divide(10, 2);
        if (result == 5) {
            System.out.println("✅ Test chia bình thường: PASS");
        } else {
            throw new AssertionError("Expected 5 but got " + result);
        }
    }
    
    // Main method để chạy test
    public static void main(String[] args) {
        AirthematicTest test = new AirthematicTest();
        
        System.out.println("Chạy các test case...");
        test.divide_ByZero_ShouldThrowException();
        test.divide_Normal_ShouldReturnCorrectValue();
        System.out.println("✅ Tất cả test đều PASS!");
    }
}