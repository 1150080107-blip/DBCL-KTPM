public class JunitMessage {
    
    // Hàm chia 2 số nguyên
    public int divide(int a, int b) {
        return a / b;   // b=0 -> Java ném ArithmeticException
    }
}