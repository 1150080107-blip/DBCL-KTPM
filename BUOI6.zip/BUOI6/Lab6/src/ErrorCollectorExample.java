import java.util.ArrayList;
import java.util.List;

public class ErrorCollectorExample {

    // Mo phong ErrorCollector Rule
    public static class ErrorCollector {
        private List<String> errors = new ArrayList<String>();

        public void checkThat(String description, Object actual, Object expected) {
            if (!actual.equals(expected)) {
                String error = description + ": Expected " + expected + " but was " + actual;
                errors.add(error);
                System.out.println("FAIL: " + error);
            } else {
                System.out.println("PASS: " + description);
            }
        }

        public void verify() {
            if (!errors.isEmpty()) {
                System.out.println("\nSUMMARY - Found " + errors.size() + " error(s):");
                for (int i = 0; i < errors.size(); i++) {
                    System.out.println("   " + (i + 1) + ". " + errors.get(i));
                }
                throw new AssertionError("Test failed with " + errors.size() + " error(s)");
            } else {
                System.out.println("\nALL CHECKS PASSED!");
            }
        }
    }

    // Mo phong @Rule
    public ErrorCollector collector = new ErrorCollector();

    // Mo phong @Test
    public void testMultipleChecks() {
        System.out.println("=== RUN ErrorCollector Test ===");

        // Check 1 - dung
        collector.checkThat("Check value 1 (5 == 5)", 5, 5);

        // Check 2 - sai
        collector.checkThat("Check value 2 (10 == 20)", 10, 20);

        // Check 3 - sai
        collector.checkThat("Check string (abc == xyz)", "abc", "xyz");

        // Check 4 - dung
        collector.checkThat("Check boolean (true == true)", true, true);

        // Check 5 - sai
        collector.checkThat("Check number (100 == 200)", 100, 200);

        System.out.println("\nTest van chay het du co loi o giua!");
        System.out.println("Day la uu diem cua ErrorCollector!");

        // Kiem tra ket qua cuoi cung
        collector.verify();
    }

    // Test so sanh voi cach thong thuong
    public void testNormalWay() {
        System.out.println("\n=== SO SANH: Cach thong thuong ===");

        try {
            // Check 1 - dung
            if (5 != 5) {
                throw new AssertionError("Check 1 failed");
            }
            System.out.println("PASS: Check 1");

            // Check 2 - sai (test se dung tai day)
            if (10 != 20) {
                throw new AssertionError("Check 2 failed: Expected 20 but was 10");
            }
            System.out.println("PASS: Check 2");

        } catch (AssertionError e) {
            System.out.println("FAIL: " + e.getMessage());
            System.out.println("Test dung ngay! Khong kiem tra duoc cac dieu kien con lai.");
        }
    }

    // Main method de chay demo
    public static void main(String[] args) {
        ErrorCollectorExample example = new ErrorCollectorExample();

        // Chay ErrorCollector test
        try {
            example.testMultipleChecks();
        } catch (AssertionError e) {
            System.out.println("\nErrorCollector da thu thap TAT CA loi truoc khi bao fail!");
        }

        System.out.println("\n============================================");

        // Chay cach thong thuong de so sanh
        example.testNormalWay();

        System.out.println("\nKET LUAN:");
        System.out.println("- ErrorCollector: Thu thap TAT CA loi");
        System.out.println("- Cach thong thuong: Dung ngay loi dau tien");
    }
}