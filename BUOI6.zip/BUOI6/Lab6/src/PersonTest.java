public class PersonTest {
    
    // 1. Test kieu @Test(expected=...) - Java thuan
    public void testPersonConstructor_NegativeAge_ShouldThrowException_Method1() {
        System.out.println("Test Method 1: @Test(expected=...) style");
        try {
            Person person = new Person("John", -5);
            // Neu khong co exception thi test fail
            throw new AssertionError("Expected IllegalArgumentException but none was thrown");
        } catch (IllegalArgumentException e) {
            System.out.println("PASS: Method 1 - Caught expected IllegalArgumentException");
            System.out.println("   Exception message: " + e.getMessage());
        }
    }
    
    // 2. Test kieu ExpectedException Rule - Java thuan
    public void testPersonConstructor_NegativeAge_ShouldThrowException_Method2() {
        System.out.println("\nTest Method 2: ExpectedException Rule style");
        
        // Mo phong ExpectedException Rule
        String expectedMessage = "Age must be >= 0";
        Class<?> expectedException = IllegalArgumentException.class;
        
        try {
            Person person = new Person("Jane", -10);
            throw new AssertionError("Expected " + expectedException.getSimpleName() + " but none was thrown");
        } catch (Exception e) {
            if (e.getClass().equals(expectedException)) {
                if (e.getMessage().equals(expectedMessage)) {
                    System.out.println("PASS: Method 2 - Correct exception type and message");
                    System.out.println("   Expected: " + expectedMessage);
                    System.out.println("   Actual: " + e.getMessage());
                } else {
                    throw new AssertionError("Wrong exception message. Expected: " + expectedMessage + ", Got: " + e.getMessage());
                }
            } else {
                throw new AssertionError("Wrong exception type. Expected: " + expectedException.getSimpleName() + ", Got: " + e.getClass().getSimpleName());
            }
        }
    }
    
    // 3. Test kieu try-catch trong test
    public void testPersonConstructor_NegativeAge_ShouldThrowException_Method3() {
        System.out.println("\nTest Method 3: try-catch style");
        
        boolean exceptionThrown = false;
        String actualMessage = "";
        
        try {
            Person person = new Person("Bob", -1);
        } catch (IllegalArgumentException e) {
            exceptionThrown = true;
            actualMessage = e.getMessage();
            System.out.println("PASS: Method 3 - Exception caught in try-catch");
            System.out.println("   Exception message: " + actualMessage);
        }
        
        if (!exceptionThrown) {
            throw new AssertionError("Expected IllegalArgumentException but none was thrown");
        }
        
        if (!"Age must be >= 0".equals(actualMessage)) {
            throw new AssertionError("Wrong exception message: " + actualMessage);
        }
    }
    
    // Test truong hop binh thuong (age >= 0)
    public void testPersonConstructor_ValidAge_ShouldCreatePerson() {
        System.out.println("\nTest Valid Case: Normal constructor");
        
        Person person = new Person("Alice", 25);
        
        if (!"Alice".equals(person.getName())) {
            throw new AssertionError("Expected name 'Alice', got: " + person.getName());
        }
        
        if (person.getAge() != 25) {
            throw new AssertionError("Expected age 25, got: " + person.getAge());
        }
        
        System.out.println("PASS: Valid Case - Person created successfully");
        System.out.println("   Name: " + person.getName() + ", Age: " + person.getAge());
    }
    
    // Main method de chay tat ca test
    public static void main(String[] args) {
        PersonTest test = new PersonTest();
        
        System.out.println("=== CHAY TAT CA TEST CASES CHO PERSON ===\n");
        
        test.testPersonConstructor_NegativeAge_ShouldThrowException_Method1();
        test.testPersonConstructor_NegativeAge_ShouldThrowException_Method2();
        test.testPersonConstructor_NegativeAge_ShouldThrowException_Method3();
        test.testPersonConstructor_ValidAge_ShouldCreatePerson();
        
        System.out.println("\nTAT CA TEST DEU PASS! - 3 KIEU TEST EXCEPTION + 1 TEST BINH THUONG");
    }
}