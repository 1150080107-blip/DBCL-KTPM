﻿using System;

namespace UnitTestLab
{
    public class MathUtil
    {
        /// <summary>
        /// Tính x^n bằng đệ quy
        /// </summary>
        /// <param name="x">Số thực</param>
        /// <param name="n">Số mũ nguyên</param>
        /// <returns>Kết quả x^n</returns>
        public static double Power(double x, int n)
        {
            // Trường hợp cơ sở: x^0 = 1
            if (n == 0)
                return 1;
            
            // Trường hợp n > 0: x^n = x^(n-1) * x
            if (n > 0)
                return Power(x, n - 1) * x;
            
            // Trường hợp n < 0: x^n = x^(n+1) / x
            // Tương đương với 1 / x^(-n)
            return Power(x, n + 1) / x;
        }
    }

    public class Polynomial
    {
        /// <summary>
        /// Tính giá trị đa thức P(x) = a0 + a1*x + a2*x^2 + ... + an*x^n
        /// </summary>
        /// <param name="coefficients">Mảng hệ số [a0, a1, a2, ..., an]</param>
        /// <param name="x">Giá trị x</param>
        /// <returns>Giá trị P(x)</returns>
        public static double Evaluate(double[] coefficients, double x)
        {
            if (coefficients == null || coefficients.Length == 0)
                return 0;

            double result = 0;
            for (int i = 0; i < coefficients.Length; i++)
            {
                result += coefficients[i] * MathUtil.Power(x, i);
            }
            return result;
        }
    }

    public class Radix
    {
        /// <summary>
        /// Chuyển đổi số từ hệ cơ số 10 sang hệ cơ số khác
        /// </summary>
        /// <param name="number">Số cần chuyển đổi</param>
        /// <param name="toBase">Hệ cơ số đích (2-36)</param>
        /// <returns>Chuỗi biểu diễn số trong hệ cơ số mới</returns>
        public static string ConvertToBase(int number, int toBase)
        {
            if (toBase < 2 || toBase > 36)
                throw new ArgumentException("Base must be between 2 and 36");

            if (number == 0)
                return "0";

            bool isNegative = number < 0;
            number = Math.Abs(number);

            string digits = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            string result = "";

            while (number > 0)
            {
                result = digits[number % toBase] + result;
                number /= toBase;
            }

            return isNegative ? "-" + result : result;
        }

        /// <summary>
        /// Chuyển đổi số từ hệ cơ số khác về hệ cơ số 10
        /// </summary>
        /// <param name="number">Chuỗi số trong hệ cơ số gốc</param>
        /// <param name="fromBase">Hệ cơ số gốc (2-36)</param>
        /// <returns>Số trong hệ cơ số 10</returns>
        public static int ConvertFromBase(string number, int fromBase)
        {
            if (fromBase < 2 || fromBase > 36)
                throw new ArgumentException("Base must be between 2 and 36");

            if (string.IsNullOrEmpty(number))
                return 0;

            bool isNegative = number.StartsWith("-");
            if (isNegative)
                number = number.Substring(1);

            string digits = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            int result = 0;

            for (int i = 0; i < number.Length; i++)
            {
                char digit = char.ToUpper(number[i]);
                int digitValue = digits.IndexOf(digit);
                
                if (digitValue == -1 || digitValue >= fromBase)
                    throw new ArgumentException($"Invalid digit '{digit}' for base {fromBase}");

                result = result * fromBase + digitValue;
            }

            return isNegative ? -result : result;
        }
    }
}
