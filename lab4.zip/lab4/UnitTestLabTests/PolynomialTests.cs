using Microsoft.VisualStudio.TestTools.UnitTesting;
using UnitTestLab;

namespace UnitTestLabTests
{
    [TestClass]
    public class PolynomialTests
    {
        [TestMethod]
        public void Evaluate_WithEmptyCoefficients_ReturnsZero()
        {
            // Arrange
            double[] coefficients = new double[0];
            double x = 5.0;
            double expected = 0.0;

            // Act
            double actual = Polynomial.Evaluate(coefficients, x);

            // Assert
            Assert.AreEqual(expected, actual, 0.0001);
        }

        [TestMethod]
        public void Evaluate_WithNullCoefficients_ReturnsZero()
        {
            // Arrange
            double[] coefficients = null;
            double x = 5.0;
            double expected = 0.0;

            // Act
            double actual = Polynomial.Evaluate(coefficients, x);

            // Assert
            Assert.AreEqual(expected, actual, 0.0001);
        }

        [TestMethod]
        public void Evaluate_WithConstantPolynomial_ReturnsConstant()
        {
            // Arrange - P(x) = 5
            double[] coefficients = { 5.0 };
            double x = 10.0;
            double expected = 5.0;

            // Act
            double actual = Polynomial.Evaluate(coefficients, x);

            // Assert
            Assert.AreEqual(expected, actual, 0.0001);
        }

        [TestMethod]
        public void Evaluate_WithLinearPolynomial_ReturnsCorrectResult()
        {
            // Arrange - P(x) = 2 + 3x
            double[] coefficients = { 2.0, 3.0 };
            double x = 4.0;
            double expected = 2.0 + 3.0 * 4.0; // = 14

            // Act
            double actual = Polynomial.Evaluate(coefficients, x);

            // Assert
            Assert.AreEqual(expected, actual, 0.0001);
        }

        [TestMethod]
        public void Evaluate_WithQuadraticPolynomial_ReturnsCorrectResult()
        {
            // Arrange - P(x) = 1 + 2x + 3x^2
            double[] coefficients = { 1.0, 2.0, 3.0 };
            double x = 2.0;
            double expected = 1.0 + 2.0 * 2.0 + 3.0 * 4.0; // = 1 + 4 + 12 = 17

            // Act
            double actual = Polynomial.Evaluate(coefficients, x);

            // Assert
            Assert.AreEqual(expected, actual, 0.0001);
        }

        [TestMethod]
        public void Evaluate_WithZeroX_ReturnsConstantTerm()
        {
            // Arrange - P(x) = 5 + 3x + 2x^2
            double[] coefficients = { 5.0, 3.0, 2.0 };
            double x = 0.0;
            double expected = 5.0; // Only constant term remains

            // Act
            double actual = Polynomial.Evaluate(coefficients, x);

            // Assert
            Assert.AreEqual(expected, actual, 0.0001);
        }
    }
}