using Microsoft.VisualStudio.TestTools.UnitTesting;
using UnitTestLab;

namespace UnitTestLabTests
{
    [TestClass]
    public class PowerTests
    {
        [TestMethod]
        public void Power_WithZeroExponent_ReturnsOne()
        {
            // Arrange
            double x = 5.0;
            int n = 0;
            double expected = 1.0;

            // Act
            double actual = MathUtil.Power(x, n);

            // Assert
            Assert.AreEqual(expected, actual, 0.0001);
        }

        [TestMethod]
        public void Power_WithPositiveExponent_ReturnsCorrectResult()
        {
            // Arrange
            double x = 2.0;
            int n = 3;
            double expected = 8.0; // 2^3 = 8

            // Act
            double actual = MathUtil.Power(x, n);

            // Assert
            Assert.AreEqual(expected, actual, 0.0001);
        }

        [TestMethod]
        public void Power_WithNegativeExponent_ReturnsCorrectResult()
        {
            // Arrange
            double x = 2.0;
            int n = -3;
            double expected = 0.125; // 2^(-3) = 1/8 = 0.125

            // Act
            double actual = MathUtil.Power(x, n);

            // Assert
            Assert.AreEqual(expected, actual, 0.0001);
        }

        [TestMethod]
        public void Power_WithBaseOne_ReturnsOne()
        {
            // Arrange
            double x = 1.0;
            int n = 100;
            double expected = 1.0;

            // Act
            double actual = MathUtil.Power(x, n);

            // Assert
            Assert.AreEqual(expected, actual, 0.0001);
        }

        [TestMethod]
        public void Power_WithNegativeBase_ReturnsCorrectResult()
        {
            // Arrange
            double x = -2.0;
            int n = 2;
            double expected = 4.0; // (-2)^2 = 4

            // Act
            double actual = MathUtil.Power(x, n);

            // Assert
            Assert.AreEqual(expected, actual, 0.0001);
        }

        [TestMethod]
        public void Power_WithNegativeBaseOddExponent_ReturnsNegativeResult()
        {
            // Arrange
            double x = -2.0;
            int n = 3;
            double expected = -8.0; // (-2)^3 = -8

            // Act
            double actual = MathUtil.Power(x, n);

            // Assert
            Assert.AreEqual(expected, actual, 0.0001);
        }

        [TestMethod]
        public void Power_WithDecimalBase_ReturnsCorrectResult()
        {
            // Arrange
            double x = 0.5;
            int n = 2;
            double expected = 0.25; // (0.5)^2 = 0.25

            // Act
            double actual = MathUtil.Power(x, n);

            // Assert
            Assert.AreEqual(expected, actual, 0.0001);
        }
    }
}