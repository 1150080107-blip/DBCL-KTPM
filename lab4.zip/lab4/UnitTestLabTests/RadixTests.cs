using Microsoft.VisualStudio.TestTools.UnitTesting;
using UnitTestLab;
using System;

namespace UnitTestLabTests
{
    [TestClass]
    public class RadixTests
    {
        [TestMethod]
        public void ConvertToBase_DecimalToBinary_ReturnsCorrectResult()
        {
            // Arrange
            int number = 10;
            int toBase = 2;
            string expected = "1010";

            // Act
            string actual = Radix.ConvertToBase(number, toBase);

            // Assert
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void ConvertToBase_DecimalToHex_ReturnsCorrectResult()
        {
            // Arrange
            int number = 255;
            int toBase = 16;
            string expected = "FF";

            // Act
            string actual = Radix.ConvertToBase(number, toBase);

            // Assert
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void ConvertToBase_ZeroToAnyBase_ReturnsZero()
        {
            // Arrange
            int number = 0;
            int toBase = 8;
            string expected = "0";

            // Act
            string actual = Radix.ConvertToBase(number, toBase);

            // Assert
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void ConvertToBase_NegativeNumber_ReturnsNegativeResult()
        {
            // Arrange
            int number = -10;
            int toBase = 2;
            string expected = "-1010";

            // Act
            string actual = Radix.ConvertToBase(number, toBase);

            // Assert
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void ConvertFromBase_BinaryToDecimal_ReturnsCorrectResult()
        {
            // Arrange
            string number = "1010";
            int fromBase = 2;
            int expected = 10;

            // Act
            int actual = Radix.ConvertFromBase(number, fromBase);

            // Assert
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void ConvertFromBase_HexToDecimal_ReturnsCorrectResult()
        {
            // Arrange
            string number = "FF";
            int fromBase = 16;
            int expected = 255;

            // Act
            int actual = Radix.ConvertFromBase(number, fromBase);

            // Assert
            Assert.AreEqual(expected, actual);
        }
    }
}