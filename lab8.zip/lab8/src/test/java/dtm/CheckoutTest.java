package dtm;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.*;

import java.time.Duration;

public class CheckoutTest {
    WebDriver driver;
    WebDriverWait wait;

    @BeforeMethod
    public void setUp() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        driver.get("https://www.saucedemo.com");
        
        // Đăng nhập
        driver.findElement(By.id("user-name")).sendKeys("standard_user");
        driver.findElement(By.id("password")).sendKeys("secret_sauce");
        driver.findElement(By.id("login-button")).click();
        
        // Đợi trang inventory load
        wait.until(ExpectedConditions.urlContains("/inventory.html"));
        
        // Thêm sản phẩm vào giỏ hàng
        driver.findElement(By.id("add-to-cart-sauce-labs-backpack")).click();
        
        // Vào giỏ hàng
        driver.findElement(By.className("shopping_cart_link")).click();
        wait.until(ExpectedConditions.urlContains("/cart.html"));
    }

    @Test(groups = {"smoke", "regression"}, description = "Kiem thu checkout thanh cong")
    public void testCheckoutSuccess() {
        // Click nút Checkout
        driver.findElement(By.id("checkout")).click();
        wait.until(ExpectedConditions.urlContains("/checkout-step-one.html"));

        // Nhập thông tin
        driver.findElement(By.id("first-name")).sendKeys("John");
        driver.findElement(By.id("last-name")).sendKeys("Doe");
        driver.findElement(By.id("postal-code")).sendKeys("12345");

        // Click Continue
        driver.findElement(By.id("continue")).click();
        wait.until(ExpectedConditions.urlContains("/checkout-step-two.html"));

        // Click Finish
        driver.findElement(By.id("finish")).click();
        wait.until(ExpectedConditions.urlContains("/checkout-complete.html"));

        // Kiểm tra thông báo thành công
        WebElement completeHeader = driver.findElement(By.className("complete-header"));
        Assert.assertEquals(completeHeader.getText(), "Thank you for your order!", 
            "Thong bao hoan thanh don hang khong dung!");
    }

    @Test(groups = {"regression"}, description = "Kiem thu checkout voi thong tin trong")
    public void testCheckoutEmptyInfo() {
        // Click nút Checkout
        driver.findElement(By.id("checkout")).click();
        wait.until(ExpectedConditions.urlContains("/checkout-step-one.html"));

        // Không nhập thông tin, click Continue luôn
        driver.findElement(By.id("continue")).click();

        // Kiểm tra thông báo lỗi
        WebElement errorMessage = wait.until(
            ExpectedConditions.visibilityOfElementLocated(By.cssSelector("[data-test='error']"))
        );
        
        Assert.assertTrue(errorMessage.isDisplayed(), 
            "Thong bao loi khong hien thi khi bo trong thong tin!");
        Assert.assertTrue(errorMessage.getText().contains("First Name is required"), 
            "Noi dung thong bao loi khong dung!");
    }

    @Test(groups = {"regression"}, description = "Kiem thu quay lai tu trang checkout")
    public void testCheckoutCancel() {
        // Click nút Checkout
        driver.findElement(By.id("checkout")).click();
        wait.until(ExpectedConditions.urlContains("/checkout-step-one.html"));

        // Click nút Cancel
        driver.findElement(By.id("cancel")).click();

        // Kiểm tra quay lại trang giỏ hàng
        wait.until(ExpectedConditions.urlContains("/cart.html"));
        String currentUrl = driver.getCurrentUrl();
        Assert.assertTrue(currentUrl.contains("/cart.html"), 
            "Khong quay lai trang gio hang sau khi cancel!");
    }

    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
