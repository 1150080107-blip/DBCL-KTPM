package dtm;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;

public class TitleTest {
    WebDriver driver;

    @BeforeMethod
    public void setUp() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.saucedemo.com");
    }

    @Test(description = "Kiem thu tieu de trang chu")
    public void testTitle() {
        String expectedTitle = "Swag Labs";
        String actualTitle = driver.getTitle();
        Assert.assertEquals(actualTitle, expectedTitle, "Tieu de trang khong dung!");
    }

    @Test(description = "Kiem thu URL trang chu")
    public void testURL() {
        String actualUrl = driver.getCurrentUrl();
        Assert.assertTrue(actualUrl.contains("saucedemo"), "URL khong hop le!");
    }

    @Test(description = "Kiem thu nguon trang (page source)")
    public void testPageSource() {
        String pageSource = driver.getPageSource();
        
        // Kiểm tra page source có chứa các thành phần quan trọng
        Assert.assertTrue(pageSource.contains("Swag Labs"), "Page source khong chua 'Swag Labs'!");
        Assert.assertTrue(pageSource.contains("login"), "Page source khong chua 'login'!");
        Assert.assertTrue(pageSource.contains("password"), "Page source khong chua 'password'!");
        
        // Kiểm tra page source không rỗng
        Assert.assertFalse(pageSource.isEmpty(), "Page source khong duoc rong!");
    }

    @Test(description = "Kiem thu form dang nhap co hien thi hay khong")
    public void testLoginFormDisplay() {
        // Kiểm tra username field có hiển thị
        WebElement usernameField = driver.findElement(By.id("user-name"));
        Assert.assertTrue(usernameField.isDisplayed(), "Username field khong hien thi!");
        
        // Kiểm tra password field có hiển thị
        WebElement passwordField = driver.findElement(By.id("password"));
        Assert.assertTrue(passwordField.isDisplayed(), "Password field khong hien thi!");
        
        // Kiểm tra login button có hiển thị
        WebElement loginButton = driver.findElement(By.id("login-button"));
        Assert.assertTrue(loginButton.isDisplayed(), "Login button khong hien thi!");
        
        // Kiểm tra logo có hiển thị
        WebElement logo = driver.findElement(By.className("login_logo"));
        Assert.assertTrue(logo.isDisplayed(), "Logo khong hien thi!");
    }

    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
