package dtm;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.*;

import java.time.Duration;

public class LoginTest {
    WebDriver driver;
    WebDriverWait wait;

    @BeforeMethod
    public void setUp() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        driver.get("https://www.saucedemo.com");
    }

    @Test(groups = {"smoke", "regression"}, description = "Kiem thu dang nhap thanh cong voi thong tin hop le")
    public void testLoginSuccess() {
        // Nhập username hợp lệ
        WebElement usernameField = driver.findElement(By.id("user-name"));
        usernameField.sendKeys("standard_user");

        // Nhập password hợp lệ
        WebElement passwordField = driver.findElement(By.id("password"));
        passwordField.sendKeys("secret_sauce");

        // Click nút Login
        WebElement loginButton = driver.findElement(By.id("login-button"));
        loginButton.click();

        // Đợi URL chuyển sang trang inventory
        wait.until(ExpectedConditions.urlContains("/inventory.html"));

        // Kiểm tra URL có chứa /inventory.html
        String currentUrl = driver.getCurrentUrl();
        Assert.assertTrue(currentUrl.contains("/inventory.html"), 
            "URL khong chuyen sang trang inventory sau khi dang nhap thanh cong!");
    }

    @Test(groups = {"regression"}, description = "Kiem thu dang nhap voi mat khau sai")
    public void testLoginWrongPassword() {
        // Nhập username đúng
        WebElement usernameField = driver.findElement(By.id("user-name"));
        usernameField.sendKeys("standard_user");

        // Nhập password sai
        WebElement passwordField = driver.findElement(By.id("password"));
        passwordField.sendKeys("wrong_password");

        // Click nút Login
        WebElement loginButton = driver.findElement(By.id("login-button"));
        loginButton.click();

        // Đợi thông báo lỗi xuất hiện
        WebElement errorMessage = wait.until(
            ExpectedConditions.visibilityOfElementLocated(
                By.cssSelector("[data-test='error']")
            )
        );

        // Kiểm tra thông báo lỗi có hiển thị
        Assert.assertTrue(errorMessage.isDisplayed(), 
            "Thong bao loi khong hien thi khi nhap sai mat khau!");

        // Kiểm tra nội dung thông báo lỗi
        String errorText = errorMessage.getText();
        Assert.assertTrue(errorText.contains("Username and password do not match"), 
            "Noi dung thong bao loi khong dung!");
    }

    @Test(groups = {"regression"}, description = "Kiem thu dang nhap voi username de trong")
    public void testLoginEmptyUsername() {
        // Bỏ trống username (không nhập gì)
        
        // Nhập password
        WebElement passwordField = driver.findElement(By.id("password"));
        passwordField.sendKeys("secret_sauce");

        // Click nút Login
        WebElement loginButton = driver.findElement(By.id("login-button"));
        loginButton.click();

        // Đợi thông báo lỗi xuất hiện
        WebElement errorMessage = wait.until(
            ExpectedConditions.visibilityOfElementLocated(
                By.cssSelector("[data-test='error']")
            )
        );

        // Kiểm tra thông báo lỗi có hiển thị
        Assert.assertTrue(errorMessage.isDisplayed(), 
            "Thong bao loi khong hien thi khi bo trong username!");

        // Kiểm tra nội dung thông báo lỗi
        String errorText = errorMessage.getText();
        Assert.assertTrue(errorText.contains("Username is required"), 
            "Thong bao loi khong dung! Mong doi: 'Username is required'");
    }

    @Test(groups = {"regression"}, description = "Kiem thu dang nhap voi password de trong")
    public void testLoginEmptyPassword() {
        // Nhập username
        WebElement usernameField = driver.findElement(By.id("user-name"));
        usernameField.sendKeys("standard_user");

        // Bỏ trống password (không nhập gì)

        // Click nút Login
        WebElement loginButton = driver.findElement(By.id("login-button"));
        loginButton.click();

        // Đợi thông báo lỗi xuất hiện
        WebElement errorMessage = wait.until(
            ExpectedConditions.visibilityOfElementLocated(
                By.cssSelector("[data-test='error']")
            )
        );

        // Kiểm tra thông báo lỗi có hiển thị
        Assert.assertTrue(errorMessage.isDisplayed(), 
            "Thong bao loi khong hien thi khi bo trong password!");

        // Kiểm tra nội dung thông báo lỗi
        String errorText = errorMessage.getText();
        Assert.assertTrue(errorText.contains("Password is required"), 
            "Thong bao loi khong dung! Mong doi: 'Password is required'");
    }

    @Test(groups = {"regression"}, description = "Kiem thu dang nhap voi tai khoan bi khoa")
    public void testLoginLockedUser() {
        // Nhập username bị khóa
        WebElement usernameField = driver.findElement(By.id("user-name"));
        usernameField.sendKeys("locked_out_user");

        // Nhập password
        WebElement passwordField = driver.findElement(By.id("password"));
        passwordField.sendKeys("secret_sauce");

        // Click nút Login
        WebElement loginButton = driver.findElement(By.id("login-button"));
        loginButton.click();

        // Đợi thông báo lỗi xuất hiện
        WebElement errorMessage = wait.until(
            ExpectedConditions.visibilityOfElementLocated(
                By.cssSelector("[data-test='error']")
            )
        );

        // Kiểm tra thông báo lỗi có hiển thị
        Assert.assertTrue(errorMessage.isDisplayed(), 
            "Thong bao loi khong hien thi khi dung tai khoan bi khoa!");

        // Kiểm tra nội dung thông báo lỗi
        String errorText = errorMessage.getText();
        Assert.assertTrue(errorText.contains("Sorry, this user has been locked out"), 
            "Thong bao loi khong dung! Mong doi: 'Sorry, this user has been locked out'");
    }

    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
