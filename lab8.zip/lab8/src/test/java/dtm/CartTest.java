package dtm;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.*;

import java.time.Duration;

public class CartTest {
    WebDriver driver;
    WebDriverWait wait;

    @BeforeMethod
    public void setUp() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        driver.get("https://www.saucedemo.com");
        
        // Đăng nhập trước khi test giỏ hàng
        driver.findElement(By.id("user-name")).sendKeys("standard_user");
        driver.findElement(By.id("password")).sendKeys("secret_sauce");
        driver.findElement(By.id("login-button")).click();
        
        // Đợi trang inventory load
        wait.until(ExpectedConditions.urlContains("/inventory.html"));
    }

    @Test(groups = {"smoke", "regression"}, description = "Kiem thu them san pham vao gio hang")
    public void testAddToCart() {
        // Click nút "Add to cart" của sản phẩm đầu tiên
        WebElement addToCartButton = driver.findElement(By.id("add-to-cart-sauce-labs-backpack"));
        addToCartButton.click();

        // Kiểm tra badge giỏ hàng hiển thị số 1
        WebElement cartBadge = wait.until(
            ExpectedConditions.visibilityOfElementLocated(By.className("shopping_cart_badge"))
        );
        
        String cartCount = cartBadge.getText();
        Assert.assertEquals(cartCount, "1", "So luong san pham trong gio hang khong dung!");
    }

    @Test(groups = {"regression"}, description = "Kiem thu xoa san pham khoi gio hang")
    public void testRemoveFromCart() {
        // Thêm sản phẩm vào giỏ hàng
        driver.findElement(By.id("add-to-cart-sauce-labs-backpack")).click();
        
        // Đợi badge hiển thị
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("shopping_cart_badge")));
        
        // Click nút "Remove"
        WebElement removeButton = driver.findElement(By.id("remove-sauce-labs-backpack"));
        removeButton.click();

        // Kiểm tra badge giỏ hàng đã biến mất
        boolean isBadgeGone = wait.until(
            ExpectedConditions.invisibilityOfElementLocated(By.className("shopping_cart_badge"))
        );
        
        Assert.assertTrue(isBadgeGone, "Badge gio hang van con hien thi sau khi xoa san pham!");
    }

    @Test(groups = {"regression"}, description = "Kiem thu them nhieu san pham vao gio hang")
    public void testAddMultipleProducts() {
        // Thêm 3 sản phẩm
        driver.findElement(By.id("add-to-cart-sauce-labs-backpack")).click();
        driver.findElement(By.id("add-to-cart-sauce-labs-bike-light")).click();
        driver.findElement(By.id("add-to-cart-sauce-labs-bolt-t-shirt")).click();

        // Kiểm tra badge hiển thị số 3
        WebElement cartBadge = wait.until(
            ExpectedConditions.visibilityOfElementLocated(By.className("shopping_cart_badge"))
        );
        
        String cartCount = cartBadge.getText();
        Assert.assertEquals(cartCount, "3", "So luong san pham trong gio hang khong dung!");
    }

    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
